import sys
sys.os("pip install numpy")