from setuptools import setup

setup(
    name='Reinforcement Learning Agents',
    version='',
    packages=[''],
    url='https://github.com/Author/diss',
    license='',
    author='Author',
    author_email='',
    description=''
    install_requires=['numpy']
)
