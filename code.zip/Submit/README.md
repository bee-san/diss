# Ways to install Pip
1. pip install numpy
2. pip install -r requirements.txt (do this in the current directory of the code)
3. python setup.py install
4. running the file "install.py"

Run the program with:
```python
python3 maze.py```

Read the lesson at Lesson.pdf or LessonMarkDown.md.
